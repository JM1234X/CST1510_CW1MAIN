raw_line = "srv-01,used=unknown,total=100"
hostname_part, rest = raw_line.split(",", 1)
for piece in rest.split(","):
    key, value = piece.split("=", 1)
    try:
        print(key, float(value.strip()))
    except ValueError:
        print(f"Cannot convert {key}: {value!r} to a number")
